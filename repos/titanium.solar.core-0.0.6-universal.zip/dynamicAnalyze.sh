#!/bin/bash
java -cp titanium.solar.core.jar titanium.solar.core.recorder.MainRecorder dynamicAnalyze.recorder.properties $@