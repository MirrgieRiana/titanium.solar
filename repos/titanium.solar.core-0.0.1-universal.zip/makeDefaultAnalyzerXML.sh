#!/bin/bash
java -cp titanium.solar.core.jar titanium.solar.core.analyzer.MainMakeDefaultAnalyzerXML $@ > analyzer.xml