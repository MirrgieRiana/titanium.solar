#!/bin/bash
java -cp titanium.solar.core.jar titanium.solar.core.recorder.analyze.MainMakeDefaultPluginAnalyzeXML $@ > analyze-plugin.xml